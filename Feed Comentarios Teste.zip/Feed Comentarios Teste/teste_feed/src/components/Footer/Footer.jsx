import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCoffee, faComment, faEnvelope, faHeart, faThumbsUp, faThumbTack } from '@fortawesome/free-solid-svg-icons';
import { faFacebook, faGithub, faInstagram, faLinkedin } from '@fortawesome/free-brands-svg-icons';

import styles from './styles.module.css';

export default function Footer() {
    return (
        <div className={styles.footer}>
            <div className={styles.footerDescription}>
                <h2>Diário do Devs</h2>
                <p>Desenvolvido por Marcos Gonçalves. Um projeto dedicado à criação de soluções tecnológicas inovadoras e acessíveis, combinando design e funcionalidade.</p>
            </div>

            <div className={styles.footerIcons}>
                <FontAwesomeIcon className={`${styles.customIcon} ${styles.facebook}`} icon={faFacebook} />
                <FontAwesomeIcon className={`${styles.customIcon} ${styles.linkedin}`} icon={faLinkedin} />
                <FontAwesomeIcon className={`${styles.customIcon} ${styles.github}`} icon={faGithub} />
                <FontAwesomeIcon className={`${styles.customIcon} ${styles.instagram}`} icon={faInstagram} />
                <FontAwesomeIcon className={`${styles.customIcon} ${styles.envelope}`} icon={faEnvelope} />
            </div>
        </div>
    );
}
