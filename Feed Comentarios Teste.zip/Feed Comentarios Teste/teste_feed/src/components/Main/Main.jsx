import { useState } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { library } from '@fortawesome/fontawesome-svg-core';
import { faCoffee, faComment, faHeart, faThumbsUp, faThumbTack } from '@fortawesome/free-solid-svg-icons';
import styles from "./styles.module.css"; // Certifique-se de que este caminho está correto

// Adiciona os ícones à biblioteca
library.add(faCoffee, faHeart, faThumbsUp, faThumbTack);

export default function Main() {
  const [email, setEmail] = useState('');
  const [nome, setNome] = useState('');
  const [comentario, setComentario] = useState('');
  const [arrayComentario, setArrayComentarios] = useState([]);

  const handleSubmit = (ev) => {
    ev.preventDefault();

    const novoComentario = {
      id: Math.floor(Math.random() * 1000000),
      nome: nome,
      email: email,
      comentario: comentario,
      createAt: new Date(),
    };

    console.log(novoComentario);
    setArrayComentarios((state) => [novoComentario, ...state]);
    setNome('');
    setEmail('');
    setComentario('');
  };

  return (
    <div className={styles.app}>
      <div className={styles.coment}>
        <h1>Vlog Programação</h1>
        <p>Comente aqui seus aprendizados em Programação</p>

        <form onSubmit={handleSubmit}>
          <label htmlFor="nome">Nome: </label>
          <input 
            type="text" 
            id="nome" 
            required 
            placeholder=" Nome..."
            value={nome}
            onChange={(ev) => setNome(ev.target.value)}
          />

          <label htmlFor="email">Email: </label>
          <input 
            type="email" 
            id="email" 
            required 
            placeholder=" Email..."
            value={email}
            onChange={(ev) => setEmail(ev.target.value)}
          />

          <label htmlFor="comentario">Comentário: </label>
          <textarea 
            id="comentario" 
            required 
            placeholder="Digite aqui seu comentário..."
            value={comentario}
            onChange={(ev) => setComentario(ev.target.value)}
          ></textarea>
          
          <button type="submit">Enviar comentário</button>
        </form>
      </div>

      <div className={styles.feedComentarios}>
        <h1>Aqui está o Feed de comentários</h1>

        <div className={styles.comentarios}>
          {arrayComentario.length > 0 ? (
            arrayComentario.map((comment) => (
              <div className={styles.commentBox} key={comment.id}>
                <div className={styles.nomeEmail}>
                  <span>Nome: {comment.nome}</span>
                  <span>Email: {comment.email}</span>
                </div>
                <span>{comment.comentario}</span>

                <div className={styles.iconsAndDate}>
                <div className={styles.icons}>
                  <FontAwesomeIcon className={styles.iconItem1} icon={faHeart} />
                  <FontAwesomeIcon className={styles.iconItem2} icon={faThumbsUp} />
                  <FontAwesomeIcon className={styles.iconItem3} icon={faComment} />
              </div>
                <span className={styles.data}>{comment.createAt.toLocaleDateString()}</span>
                </div>
              </div>
            ))
          ) : (
            <p className={styles.pComent}>Nenhum comentário ainda.</p>
          )}
        </div>
      </div>
    </div>
  );
}
