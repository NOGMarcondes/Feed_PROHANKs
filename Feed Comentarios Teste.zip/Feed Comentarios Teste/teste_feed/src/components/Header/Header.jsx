import styles from './styles.module.css'

export default function Header(){
    return(

        <div className={styles.header}>
            <h1>Diário do Devs</h1>

            <nav>
                <ul>
                    
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Sobre</a></li>
                    <li><a href="#">Contato</a></li>

                </ul>
            </nav>
        </div>
      
    )
}